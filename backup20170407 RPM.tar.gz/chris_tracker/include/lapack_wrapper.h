#ifndef LAPACK_WRAPPER_H
#define LAPACK_WRAPPER_H

void lap_eig( double *a, int n ) ;

#endif

