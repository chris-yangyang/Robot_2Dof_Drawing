///*
//
//
// * DisplayImage.cpp
// *
// *  Created on: 2016-10-19
// *      Author: junjin
// */
///**
// * OpenCV SimpleBlobDetector Example
// * Copyright 2015 by Satya Mallick <spmallick@gmail.com>
// *
// */
//
//#include "opencv2/opencv.hpp"
//
//using namespace cv;
//using namespace std;
//
//int main( int argc, char** argv )
//{
//
//	// Read image
//	Mat im = imread( argv[1], IMREAD_GRAYSCALE );
//
//	// Setup SimpleBlobDetector parameters.
//	SimpleBlobDetector::Params params;
//    //params.filterByColor=1;
//    //params.blobColor=150;
//	// Change thresholds
//	params.minThreshold = 10;
//	params.maxThreshold = 200;
//
//	// Filter by Area.
//	params.filterByArea = true;
//	params.minArea = 1500;
//
//	// Filter by Circularity
//	params.filterByCircularity = true;
//	params.minCircularity = 0.1;
//
//	// Filter by Convexity
//	params.filterByConvexity = true;
//	params.minConvexity = 0.87;
//
//	// Filter by Inertia
//	params.filterByInertia = true;
//	params.minInertiaRatio = 0.01;
//
//
//	// Storage for blobs
//	vector<KeyPoint> keypoints;
//
//
//#if CV_MAJOR_VERSION < 3   // If you are using OpenCV 2
//
//	// Set up detector with params
//	SimpleBlobDetector detector(params);
//
//	// Detect blobs
//	detector.detect( im, keypoints);
//#else
//
//	// Set up detector with params
//	Ptr<SimpleBlobDetector> detector = SimpleBlobDetector::create(params);
//
//	// Detect blobs
//	detector->detect( im, keypoints);
//#endif
//
//	// Draw detected blobs as red circles.
//	// DrawMatchesFlags::DRAW_RICH_KEYPOINTS flag ensures
//	// the size of the circle corresponds to the size of blob
//
//	Mat im_with_keypoints;
//	drawKeypoints( im, keypoints, im_with_keypoints, Scalar(255,0,0), DrawMatchesFlags::DRAW_RICH_KEYPOINTS );
//
//	// Show blobs
//	imshow("keypoints", im_with_keypoints );
//	waitKey(0);
//
//}
//
